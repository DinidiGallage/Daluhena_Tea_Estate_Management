import './App.css';
import Header from './components/header';
import AddRepair from './components/addrepair';

function App() {
  return (
    <div>
      <Header/>
      <AddRepair/>
    </div>
  );
}

export default App;
