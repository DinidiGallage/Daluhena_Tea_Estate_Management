import React, { useState } from "react";
import axios  from 'axios';

export default function AddRepair() {
    const [item_id, setItemId] = useState("");
    const [details, setDetails] = useState("");
    const [date_created, setDateCreated] = useState("");
    const [status, setStatus] = useState("Pending");
    const [tech_id, setTechId] = useState("");
    const [start_date, setDateStart] = useState("");
    const [end_date, setDateEnd] = useState("");
    const [cost, setCost] = useState("");

    const handleStatusChange = (e) => {
        setStatus(e.target.value);
    };

    function sendData(e){
        e.preventDefault(); 

        const newRepair = {
            item_id: item_id,
            details: details,
            date_created: date_created,
            status: status,
            tech_id: tech_id,
            start_date: start_date,
            end_date: end_date,
            cost: cost
        }

        axios.post('http://localhost:8070/repair/add',newRepair )
        .then((response)=>{
            console.log(response);
            alert(`New repair added!`);
            })
        
        .catch((error)=>alert(error));


        
    }

    return (
        <div className="container my-5">
            <div className="row justify-content-center">
                <div className="col-md-8">
                    <div className="card shadow">
                        <div className="card-body">
                            <h2 className="card-title text-center mb-4">Add Repair</h2>
                            <form onSubmit={sendData}>
                                <div className="mb-3">
                                    <label htmlFor="item_id" className="form-label">Item ID</label>
                                    <input type="text" className="form-control" id="item_id" value={item_id} onChange={(e) => setItemId(e.target.value)} placeholder="Enter Item ID" />
                                </div>

                                <div className="mb-3">
                                    <label htmlFor="details" className="form-label">Details</label>
                                    <input type="text" className="form-control" id="details" value={details} onChange={(e) => setDetails(e.target.value)} placeholder="Enter Repair Details" />
                                </div>

                                <div className="mb-3 row">
                                    <div className="col">
                                        <label htmlFor="date_created" className="form-label">Created Date</label>
                                        <input type="date" className="form-control" id="date_created" value={date_created} onChange={(e) => setDateCreated(e.target.value)} />
                                    </div>
                                    <div className="col">
                                        <label htmlFor="status" className="form-label">Status</label>
                                        <select className="form-select" value={status} onChange={handleStatusChange}>
                                            <option value="Pending">Pending</option>
                                            <option value="Completed">Completed</option>
                                        </select>
                                    </div>
                                </div>

                                <div className="mb-3 row">
                                    <div className="col">
                                        <label htmlFor="tech_id" className="form-label">Tech Id</label>
                                        <input type="text" className="form-control" id="tech_id" value={tech_id} onChange={(e) => setTechId(e.target.value)} placeholder="Enter tech_id" />
                                    </div>
                                    <div className="col">
                                        <label htmlFor="start_date" className="form-label">Start Date</label>
                                        <input type="date" className="form-control" id="start_date" value={start_date} onChange={(e) => setDateStart(e.target.value)} />
                                    </div>
                                </div>

                                <div className="mb-3 row">
                                    <div className="col">
                                        <label htmlFor="end_date" className="form-label">End Date</label>
                                        <input type="date" className="form-control" id="end_date" value={end_date} onChange={(e) => setDateEnd(e.target.value)} />
                                    </div>
                                    <div className="col">
                                        <label htmlFor="cost" className="form-label">Cost</label>
                                        <div className="input-group">
                                            <span className="input-group-text">$</span>
                                            <input type="text" className="form-control" id="cost" value={cost} onChange={(e) => setCost(e.target.value)} placeholder="Enter cost" />
                                        </div>
                                    </div>
                                </div>

                                <div className="text-center">
                                    <button type="submit" className="btn btn-success">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}




