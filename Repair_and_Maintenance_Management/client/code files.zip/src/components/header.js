import React from "react";

function Header() {

    return (

      <h1>Repair and Mainteneace Management System</h1>

    )
}

export default Header;